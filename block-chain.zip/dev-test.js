const Block = require('./block');
//const block = new Block();
const block = new Block('foo', 'bar', 'zoo', 'baz');
console.log(Block.genesis().toString());
console.log(block.toString())
const fooBlock = Block.mineBlock(Block.genesis(), 'foo');
console.log(fooBlock.toString());
